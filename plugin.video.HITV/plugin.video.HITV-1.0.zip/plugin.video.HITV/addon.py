import sys, urllib, urllib2, urlparse, xbmcaddon, xbmcgui, xbmcplugin, re, os, json
from cookielib import CookieJar
from base64 import b64decode
from BeautifulSoup import BeautifulSoup
try:
    import json
except:
    import simplejson as json

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

imgpath = xbmcaddon.Addon(id='plugin.video.HITV')
news_icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'news-icon.png' ) )
olelo_icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'olelo-icon.png' ) )
oc16_icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'oc16.png' ) )
others_icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'others-icon.png' ) )
	
xbmcplugin.setContent(addon_handle, 'tvshows')
	
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)
		
def make_request(url, headers=None):
	if headers is None:
		headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:15.0) Gecko/20100101 Firefox/15.0.1'}
	try:
		req = urllib2.Request(url,None,headers)
		response = urllib2.urlopen(req)
		data = response.read()
		return data
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code

def play_byu_live():
	soup = BeautifulSoup(make_request('http://www.byutv.org/api/Television/GetLiveStreamUrl?context=Android%24US%24Release'))
	urlCode = soup.getText().strip('"')
	reqUrl = 'http://player.ooyala.com/sas/player_api/v1/authorization/embed_code/Iyamk6YZTw8DxrC60h0fQipg3BfL/'+urlCode+'?device=android_3plus_sdk-hook&domain=www.ooyala.com&supportedFormats=mp4%2Cm3u8%2Cwv_hls%2Cwv_wvm2Cwv_mp4'
	data = json.loads(make_request(reqUrl))
	for stream in data['authorization_data'][urlCode]['streams']:
		url = b64decode(stream['url']['data'])
		return url
			
def get_livestream_url(url):
	res = urllib2.urlopen(url).read()
	for numbers in re.findall("http://livestream.com/accounts/(\d+)/events/(\d+)",res):
		k,j = numbers
	jsontext = res.split('window.config = ')[1].split(';</script>')[0]
	js = json.loads(jsontext)
	m3u8_url = js['event']['stream_info']['m3u8_url']
	cj = CookieJar()
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	res = opener.open(m3u8_url)
	ua="Player/LG Player 1.0 for Android 5.0.1 (stagefright alternative)"
	cookies = ["_alid_=" + res.info().getheader('Set-Cookie').split('_alid_=')[1].split('; ')[0]]
	cookies.append("hdntl=" + res.info().getheader('Set-Cookie').split('hdntl=')[1].split('; ')[0])
	cookie = '; '.join(cookies)
	print "saiko JS: %s" % js
	
	res = res.read()

	resolutions = re.findall("RESOLUTION=(\d{3,4}x\d{3,4}),CODECS",res)
	high_res = sorted(resolutions)[-1]
	play_m3u8 = None
	for i,line in enumerate(res.splitlines()):
		if high_res in line:
			play_m3u8 = res.splitlines()[i+1].strip()
			url = play_m3u8 + "|Cookie=%s&User-Agent=%s" % (cookie,ua)
			return url
	
mode = args.get('mode', None)

if mode is None:
    url = build_url({'mode': 'folder', 'foldername': 'News'})
    li = xbmcgui.ListItem('News', iconImage=news_icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'OC16'})
    li = xbmcgui.ListItem('OC16', iconImage=oc16_icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'Olelo'})
    li = xbmcgui.ListItem("'"'Olelo', iconImage=olelo_icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    url = build_url({'mode': 'folder', 'foldername': 'Other'})
    li = xbmcgui.ListItem('Other', iconImage=others_icon)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'folder':
	foldername = args['foldername'][0]
	if foldername == 'News':
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'khnl.png' ) )
		url = get_livestream_url("http://livestream.com/khnl/live")
		li = xbmcgui.ListItem(foldername + ' - Hawaii News Now', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'khon2.png' ) )
		url = get_livestream_url("http://livestream.com/khon/live")
		li = xbmcgui.ListItem(foldername + ' - KHON2', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'k5.png' ) )
		url = get_livestream_url("http://livestream.com/kfve/live")
		li = xbmcgui.ListItem(foldername + ' - K5', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		xbmcplugin.endOfDirectory(addon_handle)
		
	elif foldername == 'OC16':
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'oc16.png' ) )
		url = 'rtmp://24.25.235.76:1935/live/_definst_/oc16_2000 live=true buffer=2000'
		li = xbmcgui.ListItem(foldername, iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'xcast1.png' ) )
		url = 'rtmp://24.25.235.76:1935/live/_definst_/xcast1_750 live=true buffer=2000'
		li = xbmcgui.ListItem(foldername + ' - Xcast1', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'xcast2.png' ) )
		url = 'rtmp://24.25.235.76:1935/live/_definst_/xcast2_750 live=true buffer=2000'
		li = xbmcgui.ListItem(foldername + ' - Xcast2', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
	
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'xcast3.png' ) )
		url = 'rtmp://24.25.235.76:1935/live/_definst_/xcast3_750 live=true buffer=2000'
		li = xbmcgui.ListItem(foldername + ' - Xcast3', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		xbmcplugin.endOfDirectory(addon_handle)
		
	elif foldername == 'Olelo':
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'olelo_49.png' ) )
		url = 'rtmp://granicus.mpl.miisolutions.net/granicus-livepull-us-4/olelo/mp4:G0125_009'
		li = xbmcgui.ListItem(foldername + ' - 49 FOCUS', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'olelo_53.png' ) )
		url = 'rtmp://granicus.mpl.miisolutions.net/granicus-livepull-us-4/olelo/mp4:G0125_011'
		li = xbmcgui.ListItem(foldername + ' - 53 NATV', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'olelo_54.png' ) )
		url = 'rtmp://granicus.mpl.miisolutions.net/granicus-livepull-us-4/olelo/mp4:G0125_012'
		li = xbmcgui.ListItem(foldername + ' - 54 VIEWS', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'olelo_55.png' ) )
		url = 'rtmp://granicus.mpl.miisolutions.net/granicus-livepull-us-4/olelo/mp4:G0125_013'
		li = xbmcgui.ListItem(foldername + ' - 55 OAHU', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'olelo_traffic.png' ) )
		url = 'rtmp://granicus.mpl.miisolutions.net/granicus-livepull-us-4/olelo/mp4:G0125_017'
		li = xbmcgui.ListItem(foldername + ' - TRAFFIC', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		xbmcplugin.endOfDirectory(addon_handle)
		
	elif foldername == 'Other':
		icon = xbmc.translatePath( os.path.join( imgpath.getAddonInfo('path'), 'imgs', 'byu-icon.png' ) )
		url = play_byu_live()
		li = xbmcgui.ListItem('BYUTV Live', iconImage=icon)
		xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
		
		xbmcplugin.endOfDirectory(addon_handle)